# books/models.py

from django.db import models

class Author(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.name  # Shows name in Django admin

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(
        Author,
        on_delete=models.CASCADE,   # If author deleted, delete their books too
        related_name='books'
    )
    isbn = models.CharField(max_length=13, unique=True)  # ISBN = book's unique ID
    published_date = models.DateField()
    is_available = models.BooleanField(default=True)     # Is it borrowed or not?

    def __str__(self):
        return self.title