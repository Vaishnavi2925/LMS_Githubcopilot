from django.contrib import admin
from .models import Author, Book


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'email']
    search_fields = ['name', 'email']
    list_filter = ['name']


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'author', 'isbn', 'published_date', 'is_available']
    search_fields = ['title', 'isbn', 'author__name']
    list_filter = ['is_available', 'published_date', 'author']
    readonly_fields = ['isbn']
