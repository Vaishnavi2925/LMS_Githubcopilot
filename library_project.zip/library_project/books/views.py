from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import render
from .models import Author, Book
from .serializers import AuthorSerializer, BookSerializer


class AuthorViewSet(viewsets.ModelViewSet):
    """
    API endpoint for managing Authors.
    Supports GET, POST, PUT, DELETE, PATCH operations.
    """
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer


class BookViewSet(viewsets.ModelViewSet):
    """
    API endpoint for managing Books.
    Supports GET, POST, PUT, DELETE, PATCH operations.
    """
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    
    @action(detail=True, methods=['post'])
    def toggle_availability(self, request, pk=None):
        """Toggle the availability status of a book."""
        book = self.get_object()
        book.is_available = not book.is_available
        book.save()
        return Response({
            'status': 'book availability updated',
            'is_available': book.is_available
        })
    
    @action(detail=False, methods=['get'])
    def available_books(self, request):
        """Get all available books."""
        available = Book.objects.filter(is_available=True)
        serializer = self.get_serializer(available, many=True)
        return Response(serializer.data)


def index(request):
    """Serve the main dashboard page."""
    return render(request, 'books/index.html')
