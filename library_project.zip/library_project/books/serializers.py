from rest_framework import serializers
from .models import Author, Book


class AuthorSerializer(serializers.ModelSerializer):
    books_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Author
        fields = ['id', 'name', 'email', 'books_count']
    
    def get_books_count(self, obj):
        return obj.books.count()


class BookSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(write_only=True, required=False)
    author_display = serializers.CharField(source='author.name', read_only=True)
    
    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'author_name', 'author_display', 'isbn', 'published_date', 'is_available']
    
    def create(self, validated_data):
        author_name = validated_data.pop('author_name', None)
        author_id = validated_data.get('author')
        
        # If author_name is provided, use it to find or create an author
        if author_name:
            author, created = Author.objects.get_or_create(
                name=author_name,
                defaults={'email': f'{author_name.lower().replace(" ", ".")}@library.com'}
            )
            validated_data['author'] = author
        
        return Book.objects.create(**validated_data)
    
    def update(self, instance, validated_data):
        author_name = validated_data.pop('author_name', None)
        
        # If author_name is provided, use it to find or create an author
        if author_name:
            author, created = Author.objects.get_or_create(
                name=author_name,
                defaults={'email': f'{author_name.lower().replace(" ", ".")}@library.com'}
            )
            validated_data['author'] = author
        
        return super().update(instance, validated_data)
