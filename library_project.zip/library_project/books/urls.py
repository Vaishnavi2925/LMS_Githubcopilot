from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# Create a router and register viewsets
router = DefaultRouter()
router.register(r'authors', views.AuthorViewSet)
router.register(r'books', views.BookViewSet)

app_name = 'books'

urlpatterns = [
    # API endpoints
    path('api/', include(router.urls)),
    # Dashboard page
    path('', views.index, name='index'),
]
