#!/usr/bin/env python
"""
Setup script for Library Management System
This script will:
1. Install required packages
2. Run migrations
3. Create a superuser
4. Load sample data (optional)
"""

import os
import sys
import django
from pathlib import Path

# Add the project directory to the path
project_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(project_dir))

# Set Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'library_project.settings')

# Setup Django
django.setup()

from django.core.management import call_command
from django.contrib.auth.models import User
from books.models import Author, Book
from datetime import date


def print_header(text):
    print("\n" + "="*60)
    print(f"  {text}")
    print("="*60)


def run_migrations():
    print_header("Running Migrations")
    try:
        call_command('migrate', verbosity=1)
        print("✅ Migrations completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Error running migrations: {e}")
        return False


def create_superuser():
    print_header("Creating Superuser")
    
    # Check if superuser already exists
    if User.objects.filter(is_superuser=True).exists():
        print("⚠️  Superuser already exists!")
        return True
    
    try:
        username = input("Enter superuser username (default: admin): ").strip() or "admin"
        email = input("Enter superuser email (default: admin@library.com): ").strip() or "admin@library.com"
        password = input("Enter superuser password (default: admin123): ").strip() or "admin123"
        
        User.objects.create_superuser(username=username, email=email, password=password)
        print(f"✅ Superuser '{username}' created successfully!")
        print(f"📧 Email: {email}")
        print(f"🔑 Password: {password}")
        return True
    except Exception as e:
        print(f"❌ Error creating superuser: {e}")
        return False


def load_sample_data():
    print_header("Load Sample Data?")
    
    choice = input("Do you want to load sample books and authors? (y/n): ").strip().lower()
    
    if choice != 'y':
        print("⏭️  Skipping sample data...")
        return True
    
    try:
        # Clear existing data
        Book.objects.all().delete()
        Author.objects.all().delete()
        
        # Create sample authors
        authors_data = [
            {"name": "J.K. Rowling", "email": "jk@harrypotter.com"},
            {"name": "George R.R. Martin", "email": "george@gameofthrones.com"},
            {"name": "J.R.R. Tolkien", "email": "jrr@lotr.com"},
            {"name": "Agatha Christie", "email": "agatha@mystery.com"},
            {"name": "Stephen King", "email": "stephen@horror.com"},
        ]
        
        authors = []
        for author_data in authors_data:
            author, created = Author.objects.get_or_create(
                name=author_data["name"],
                email=author_data["email"]
            )
            authors.append(author)
            print(f"  {'✅ Created' if created else '⚠️  Exists:'} {author.name}")
        
        # Create sample books
        books_data = [
            {"title": "Harry Potter and the Philosopher's Stone", "author": authors[0], "isbn": "9780747532699", "published_date": "1997-06-26", "is_available": True},
            {"title": "Harry Potter and the Chamber of Secrets", "author": authors[0], "isbn": "9780747538493", "published_date": "1998-07-02", "is_available": True},
            {"title": "A Game of Thrones", "author": authors[1], "isbn": "9780553103540", "published_date": "1996-08-06", "is_available": False},
            {"title": "A Clash of Kings", "author": authors[1], "isbn": "9780553108033", "published_date": "1998-11-16", "is_available": True},
            {"title": "The Fellowship of the Ring", "author": authors[2], "isbn": "9780544003415", "published_date": "1954-07-29", "is_available": True},
            {"title": "The Two Towers", "author": authors[2], "isbn": "9780544003492", "published_date": "1954-11-11", "is_available": True},
            {"title": "Murder on the Orient Express", "author": authors[3], "isbn": "9780062693556", "published_date": "1934-01-01", "is_available": False},
            {"title": "The Shining", "author": authors[4], "isbn": "9780385333312", "published_date": "1977-01-28", "is_available": True},
        ]
        
        for book_data in books_data:
            book, created = Book.objects.get_or_create(
                title=book_data["title"],
                author=book_data["author"],
                isbn=book_data["isbn"],
                published_date=book_data["published_date"],
                is_available=book_data["is_available"]
            )
            print(f"  {'✅ Added' if created else '⚠️  Exists:'} {book.title}")
        
        print(f"\n✅ Sample data loaded successfully!")
        print(f"   📚 Total books: {Book.objects.count()}")
        print(f"   👥 Total authors: {Author.objects.count()}")
        return True
    
    except Exception as e:
        print(f"❌ Error loading sample data: {e}")
        return False


def main():
    print("\n")
    print("╔════════════════════════════════════════════════════════════╗")
    print("║   📚 Library Management System - Setup                    ║")
    print("╚════════════════════════════════════════════════════════════╝")
    
    # Step 1: Run migrations
    if not run_migrations():
        print("\n❌ Setup failed at migrations step!")
        return
    
    # Step 2: Create superuser
    if not create_superuser():
        print("\n⚠️  Warning: Superuser creation failed, but you can create one manually later.")
    
    # Step 3: Load sample data
    load_sample_data()
    
    # Summary
    print_header("✅ Setup Complete!")
    print("\n🎉 Your Library Management System is ready!")
    print("\n📋 Next steps:")
    print("   1. Start the development server:")
    print("      python manage.py runserver")
    print("\n   2. Access the application:")
    print("      🌐 Dashboard: http://localhost:8000/")
    print("      🔐 Admin: http://localhost:8000/admin/")
    print("      🔌 API: http://localhost:8000/api/")
    print("\n   3. API Endpoints:")
    print("      - GET/POST    /api/books/       - List/Create books")
    print("      - GET/PUT     /api/books/<id>/  - Retrieve/Update book")
    print("      - DELETE      /api/books/<id>/  - Delete book")
    print("      - GET/POST    /api/authors/     - List/Create authors")
    print("      - GET/PUT     /api/authors/<id>/ - Retrieve/Update author")
    print("      - DELETE      /api/authors/<id>/ - Delete author")
    print("\n" + "="*60 + "\n")


if __name__ == '__main__':
    main()
